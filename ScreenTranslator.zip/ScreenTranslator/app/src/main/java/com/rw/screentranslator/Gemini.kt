package com.rw.screentranslator

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object Gemini {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private fun call(model: String, key: String, body: JSONObject): JSONObject {
        if (key.isBlank()) throw IOException("No API key. Open the app and paste your Gemini key.")
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("Gemini error ${r.code}: ${s.take(300)}")
            return JSONObject(s)
        }
    }

    private fun parts(res: JSONObject): JSONArray =
        res.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")

    private fun text(res: JSONObject): String {
        val p = try {
            parts(res)
        } catch (e: Exception) {
            throw IOException("Empty reply from Gemini")
        }
        val sb = StringBuilder()
        for (i in 0 until p.length()) sb.append(p.getJSONObject(i).optString("text"))
        val out = sb.toString().trim()
        if (out.isEmpty()) throw IOException("Empty reply from Gemini")
        return out
    }

    private fun contents(vararg items: JSONObject): JSONObject {
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        return JSONObject().put(
            "contents",
            JSONArray().put(JSONObject().put("parts", arr))
        )
    }

    /** Reads the text on a screenshot and translates it into the chosen language. */
    fun translateScreen(p: Prefs, jpegB64: String): String {
        val prompt = "Read all meaningful text visible in this phone screenshot " +
            "(ignore status bar and navigation buttons). Translate it into ${p.lang}. " +
            "Keep the original order and short paragraphs. Output only the translation, " +
            "no explanations. If there is no text, describe in one sentence what is on " +
            "screen, in ${p.lang}."
        val body = contents(
            JSONObject().put("text", prompt),
            JSONObject().put(
                "inline_data",
                JSONObject().put("mime_type", "image/jpeg").put("data", jpegB64)
            )
        )
        return text(call(p.model, p.apiKey, body))
    }

    /** Text guide for signing the translation (Gemini cannot produce sign-language video). */
    fun signGuide(p: Prefs, translated: String): String {
        val prompt = "Text (in ${p.lang}):\n$translated\n\n" +
            "Give a sign-language guide for this text. Use Rwandan Sign Language when you " +
            "know the sign, otherwise say 'ASL/International Sign'. Format: a numbered list " +
            "in signing order, each line: GLOSS - handshape, location, movement (max 15 words). " +
            "Only the 10 most important signs. Write explanations in ${p.lang}. " +
            "Be honest if you are unsure of a sign."
        return text(call(p.model, p.apiKey, contents(JSONObject().put("text", prompt))))
    }

    /** Gemini text-to-speech. Returns raw 16-bit PCM, 24 kHz, mono. */
    fun speech(p: Prefs, text: String): ByteArray {
        val body = contents(JSONObject().put("text", text))
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put(
                                "prebuiltVoiceConfig",
                                JSONObject().put("voiceName", "Kore")
                            )
                        )
                    )
            )
        val res = call(Prefs.TTS_MODEL, p.apiKey, body)
        val data = try {
            parts(res).getJSONObject(0).getJSONObject("inlineData").getString("data")
        } catch (e: Exception) {
            throw IOException("Gemini returned no audio")
        }
        return Base64.decode(data, Base64.DEFAULT)
    }
}
