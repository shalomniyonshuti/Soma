package com.rw.screentranslator

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText
    private lateinit var langSpin: Spinner

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(24))
        }

        fun label(t: String, size: Float = 14f) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, dp(12), 0, dp(4))
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false
            setOnClickListener { onClick() }
        }

        col.addView(label("Screen Translator", 24f))
        col.addView(label("Floating button that reads your screen, translates it with Gemini, and speaks it."))

        col.addView(label("Gemini API key"))
        keyBox = EditText(this).apply {
            setText(prefs.apiKey)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        col.addView(keyBox)

        col.addView(label("Gemini model"))
        modelBox = EditText(this).apply {
            setText(prefs.model)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        col.addView(modelBox)

        col.addView(label("Translate into"))
        langSpin = Spinner(this)
        val names = Prefs.LANGS.keys.toList()
        langSpin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        langSpin.setSelection(names.indexOf(prefs.lang).coerceAtLeast(0))
        col.addView(langSpin)

        col.addView(label(" "))
        col.addView(button("1. Allow display over other apps") {
            if (Settings.canDrawOverlays(this)) {
                toast("Already allowed")
            } else {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        })
        col.addView(button("2. Start floating translator") { startTranslator() })
        col.addView(button("Stop") {
            stopService(Intent(this, OverlayService::class.java))
            toast("Stopped")
        })
        col.addView(
            label(
                "Tip: when Android asks what to share, choose \"Entire screen\" so the " +
                    "button can read other apps."
            )
        )

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun saveSettings() {
        prefs.apiKey = keyBox.text.toString()
        prefs.model = modelBox.text.toString()
        prefs.lang = langSpin.selectedItem as String
    }

    private fun startTranslator() {
        saveSettings()
        if (!Settings.canDrawOverlays(this)) {
            toast("Do step 1 first")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7)
            return
        }
        askCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) askCapture() // continue even if notifications were denied
    }

    private fun askCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 42)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .putExtra(OverlayService.EXTRA_CODE, resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                startForegroundService(i)
                toast("Floating \"Tr\" button started")
                moveTaskToBack(true)
            } else {
                toast("Screen capture permission was not granted")
            }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
