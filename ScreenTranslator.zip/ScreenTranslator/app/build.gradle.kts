plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rw.screentranslator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rw.screentranslator"
        minSdk = 26          // Android 8.0 and above
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Optional: the GitHub Action injects the secret GEMINI_API_KEY here.
        // You can also paste the key inside the app's settings screen.
        val key = System.getenv("GEMINI_API_KEY") ?: ""
        buildConfigField("String", "GEMINI_API_KEY", "\"$key\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug") // test builds install directly
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
