# Screen Translator

Floating button for Android 8.0+ that reads what is on your screen, translates it with the
Gemini API (Kinyarwanda, English, French, Swahili), speaks it, and gives a sign-language guide.

## Get the APK (no computer needed to build)
1. Create a new GitHub repository (private recommended) and upload all these files.
2. Optional: Settings > Secrets and variables > Actions > New secret, name `GEMINI_API_KEY`.
   (Or just paste the key inside the app later.)
3. Open the Actions tab > "Build APK" > Run workflow (it also runs on every push).
4. When it finishes, open the repo's Releases page on your phone and download `ScreenTranslator.apk`.
5. Allow "Install unknown apps" for your browser, then install.

## Use
1. Open the app, paste your Gemini key, pick a language.
2. Tap "1. Allow display over other apps", enable it, come back.
3. Tap "2. Start floating translator", accept screen capture (choose "Entire screen").
4. Go to any app and tap the green **Tr** button. Drag it to move it.
5. In the result panel: **Speak** reads it aloud, **Sign** shows a sign guide,
   **Lang** switches language and re-translates, **Close** hides the panel.

## Notes
- Model names change over time. If you get a 404 error, change the model in the app
  (default `gemini-2.5-flash`). Voice fallback uses `Prefs.TTS_MODEL` in `Prefs.kt`.
- Sign language is text guidance (gloss + handshape), not video.
