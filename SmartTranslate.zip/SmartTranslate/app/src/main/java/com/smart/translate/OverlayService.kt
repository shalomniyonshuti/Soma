package com.smart.translate
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class OverlayService : Service() {
  lateinit var wm: WindowManager
  var proj: MediaProjection? = null; var reader: ImageReader? = null
  lateinit var bubble: ImageView; lateinit var panel: LinearLayout; lateinit var out: TextView; lateinit var input: EditText
  var tts: TextToSpeech? = null; var shot: String? = null; var last = ""; var hist = JSONArray()
  val h = Handler(Looper.getMainLooper())
  fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
  fun pref(k: String, d: String) = getSharedPreferences("s", 0).getString(k, d)!!
  fun loc(): Locale = when (pref("lang", "")) { "Kinyarwanda" -> Locale("rw", "RW"); "French" -> Locale.FRENCH; "Swahili" -> Locale("sw"); "Spanish" -> Locale("es"); "Arabic" -> Locale("ar"); "Chinese" -> Locale.CHINESE; "Portuguese" -> Locale("pt"); "German" -> Locale.GERMAN; "Hindi" -> Locale("hi"); else -> Locale.ENGLISH }
  override fun onBind(i: Intent?): IBinder? = null

  override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
    if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("s", "Smart Translate", NotificationManager.IMPORTANCE_LOW))
    val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
    if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
    val n = Notification.Builder(this, "s").setContentTitle("Smart Translate is running").setContentText("Tap the floating logo to use it").setSmallIcon(R.mipmap.ic_launcher)
      .addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
    if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, n)
    if (i == null || proj != null) return START_NOT_STICKY
    val data = i.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
    proj = (getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(i.getIntExtra("code", -1), data)
    proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
    val m = resources.displayMetrics
    reader = ImageReader.newInstance(m.widthPixels, m.heightPixels, PixelFormat.RGBA_8888, 2)
    proj!!.createVirtualDisplay("st", m.widthPixels, m.heightPixels, m.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
    wm = getSystemService(WINDOW_SERVICE) as WindowManager
    tts = TextToSpeech(this) {}
    buildUi()
    return START_NOT_STICKY
  }

  fun lp(w: Int, hh: Int) = WindowManager.LayoutParams(w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
  fun grad(c1: String, c2: String, r: Int) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply { cornerRadius = dp(r).toFloat() }
  fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setTextColor(Color.WHITE); textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0; setPadding(dp(4), 0, dp(4), 0); background = grad("#00A3FF", "#B100FF", 18); setOnClickListener { a() } }
  fun small(t: String, a: () -> Unit) = btn(t, a).apply { background = grad("#3A4A9F", "#3A4A9F", 16) }

  fun buildUi() {
    val sw = resources.displayMetrics.widthPixels
    bubble = ImageView(this).apply { setImageResource(R.drawable.logo); setPadding(dp(4), dp(4), dp(4), dp(4)) }
    val bp = lp(dp(58), dp(58)).apply { gravity = Gravity.TOP or Gravity.START; x = sw - dp(58); y = dp(220) }
    var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
    bubble.setOnTouchListener { _, e ->
      when (e.action) {
        MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = bp.x; oy = bp.y; moved = false }
        MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - sx) > 10 || Math.abs(e.rawY - sy) > 10) moved = true; bp.x = ox + (e.rawX - sx).toInt(); bp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(bubble, bp) }
        MotionEvent.ACTION_UP -> if (!moved) panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
          else { bp.x = if (e.rawX < sw / 2) 0 else sw - dp(58); wm.updateViewLayout(bubble, bp) }
      }
      true
    }
    panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(dp(12), dp(10), dp(12), dp(12))
      background = GradientDrawable().apply { setColor(Color.parseColor("#F20B1030")); cornerRadius = dp(22).toFloat(); setStroke(dp(2), Color.parseColor("#7B2FFF")) } }
    val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
    head.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(dp(26), dp(26)))
    head.addView(TextView(this).apply { text = "  Smart Translate"; setTextColor(Color.WHITE); textSize = 15f }, LinearLayout.LayoutParams(0, -2, 1f))
    head.addView(small("⏻") { stopSelf() }, LinearLayout.LayoutParams(dp(40), dp(34)))
    head.addView(small("✕") { panel.visibility = View.GONE }, LinearLayout.LayoutParams(dp(40), dp(34)).apply { leftMargin = dp(4) })
    panel.addView(head)
    out = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(dp(4), dp(8), dp(4), dp(8)); text = "Choose an action below to read this screen." }
    panel.addView(ScrollView(this).apply { addView(out) }, LinearLayout.LayoutParams(-1, dp(230)))
    val row = LinearLayout(this); val l = { pref("lang", "Kinyarwanda") }
    val rd = "Read ALL text in this screenshot, keep its order. First line: 'Detected: <language>'. Then a blank line, then the full translation into "
    listOf<Pair<String, () -> Unit>>(
      "🌐 Translate" to { act(rd + "${l()}. Plain text only.", false, true) },
      "🤟 Sign" to { act("Read the main text in this screenshot. Give it in sign language: first the sign glosses (sign-language word order), then for each key sign a short description of handshape, location and movement. Write in ${l()}. Plain text only.", false, true) },
      "🔊 Speak" to { act(rd + "${l()}. Plain text only.", true, true) }
    ).forEach { (t, a) -> row.addView(btn(t, a), LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(4), dp(2), 0) }) }
    panel.addView(row)
    val tools = LinearLayout(this)
    listOf<Pair<String, () -> Unit>>(
      "📋 Copy" to { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", last)); Toast.makeText(this, "Copied", 0).show() },
      "▶ Read aloud" to { if (tts?.isSpeaking == true) tts?.stop() else speak() },
      "🔄 New" to { shot = null; hist = JSONArray(); last = ""; out.text = "Ready. Choose an action." }
    ).forEach { (t, a) -> tools.addView(small(t, a), LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(dp(2), dp(6), dp(2), 0) }) }
    panel.addView(tools)
    val ask = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
    input = EditText(this).apply { hint = "Ask about this page, any language"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 13f; setSingleLine() }
    ask.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
    ask.addView(small("🎤") { mic() }, LinearLayout.LayoutParams(dp(44), dp(40)))
    ask.addView(btn("➤") { send() }, LinearLayout.LayoutParams(dp(44), dp(40)).apply { leftMargin = dp(4) })
    panel.addView(ask)
    wm.addView(panel, lp(minOf(sw - dp(24), dp(340)), -2).apply { gravity = Gravity.CENTER })
    wm.addView(bubble, bp)
  }

  fun say(t: String) = h.post { out.text = t }
  fun clean(t: String) = t.replace("**", "").replace(Regex("(?m)^#+ *"), "").replace(Regex("(?m)^\\* "), "• ").trim()
  fun speak() { if (last.isBlank()) return
    val r = tts?.setLanguage(loc())
    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) Toast.makeText(this, "Voice for ${pref("lang", "")} not installed. Install it in Settings > Text-to-speech.", 1).show()
    else tts?.speak(last, TextToSpeech.QUEUE_FLUSH, null, "x") }

  fun send() { val q = input.text.toString().trim(); if (q.isEmpty()) return; input.setText("")
    act("Answer in the SAME language this question is written in, plain text, concise: $q", false, shot == null) }

  fun mic() {
    if (checkSelfPermission("android.permission.RECORD_AUDIO") != 0) { say("Open the app once and allow the microphone."); return }
    if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Voice input is not available on this phone."); return }
    val r = SpeechRecognizer.createSpeechRecognizer(this); say("Listening...")
    r.setRecognitionListener(object : RecognitionListener {
      override fun onResults(b: Bundle?) { val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); r.destroy(); if (t != null) { input.setText(t); send() } }
      override fun onError(e: Int) { r.destroy(); say("Didn't catch that. Tap 🎤 and try again.") }
      override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
      override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}; override fun onEvent(t: Int, b: Bundle?) {}
    })
    r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "free_form").putExtra(RecognizerIntent.EXTRA_LANGUAGE, loc().toLanguageTag()))
  }

  fun part(t: String) = JSONObject().put("text", t)
  fun act(prompt: String, speak: Boolean, fresh: Boolean) {
    out.text = "Working..."; bubble.alpha = 0.5f
    if (!fresh && shot != null) { ask(JSONArray().put(part(prompt)), speak); return }
    panel.visibility = View.INVISIBLE; bubble.visibility = View.INVISIBLE
    grab(0) { b64 ->
      panel.visibility = View.VISIBLE; bubble.visibility = View.VISIBLE
      if (b64 == null) { bubble.alpha = 1f; say("Could not capture the screen. Try again.") }
      else { shot = b64; hist = JSONArray(); ask(JSONArray().put(part(prompt)).put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64))), speak) }
    }
  }

  fun grab(n: Int, cb: (String?) -> Unit) = h.postDelayed({
    val img = try { reader!!.acquireLatestImage() } catch (e: Exception) { null }
    if (img == null) { if (n < 8) grab(n + 1, cb) else cb(null); return@postDelayed }
    val p = img.planes[0]; val w = img.width; val hh = img.height
    val full = Bitmap.createBitmap(p.rowStride / p.pixelStride, hh, Bitmap.Config.ARGB_8888); full.copyPixelsFromBuffer(p.buffer); img.close()
    val bm = Bitmap.createScaledBitmap(Bitmap.createBitmap(full, 0, 0, w, hh), 1080, (hh * 1080f / w).toInt(), true)
    val bo = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG, 85, bo)
    cb(Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP))
  }, if (n == 0) 400 else 250)

  fun ask(parts: JSONArray, speak: Boolean) = Thread {
    val user = JSONObject().put("role", "user").put("parts", parts)
    hist.put(user)
    try {
      val models = listOf(pref("model", "gemini-2.5-flash"), "gemini-2.5-flash-lite", "gemini-2.0-flash").distinct()
      var err = ""
      for (m in models) {
        val body = JSONObject().put("contents", hist).put("systemInstruction", JSONObject().put("parts", JSONArray().put(part("You are a precise screen reading, translation and sign-language assistant. Reply in plain text without markdown."))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 20000; c.readTimeout = 90000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", pref("key", ""))
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode; val s = (if (code < 300) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code < 300) {
          val cand = JSONObject(s).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
          last = clean(cand.getJSONArray("parts").getJSONObject(0).getString("text")); hist.put(cand.put("role", "model"))
          say(last); if (speak) h.post { speak() }; h.post { bubble.alpha = 1f }; return@Thread
        }
        err = "Error $code: " + (JSONObject(s).optJSONObject("error")?.optString("message") ?: "")
        if (code == 400 || code == 401 || code == 403) break
      }
      hist.remove(hist.length() - 1); say("$err\n\nCheck your API key in the app (Test key).")
    } catch (e: Exception) { hist.remove(hist.length() - 1); say("Network error: ${e.message}") }
    h.post { bubble.alpha = 1f }
  }.start()

  override fun onDestroy() { try { wm.removeView(bubble); wm.removeView(panel) } catch (e: Exception) {}; proj?.stop(); tts?.shutdown() }
}
