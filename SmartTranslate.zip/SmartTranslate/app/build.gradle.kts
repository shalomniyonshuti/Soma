plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
  namespace = "com.smart.translate"
  compileSdk = 34
  defaultConfig { applicationId = "com.smart.translate"; minSdk = 26; targetSdk = 34; versionCode = 2; versionName = "2.0" }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
