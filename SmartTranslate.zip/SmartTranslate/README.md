# Smart Translate 2.0
1. Create a GitHub repo and upload ALL files (keep the .github folder).
2. Actions > Build APK > download artifact SmartTranslate-APK > unzip > install app-debug.apk.
3. Open the app: paste key, Test key, choose language, Start.
Never put your API key in code or in the repo.
